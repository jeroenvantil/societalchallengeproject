---------------------------------------------------------------------------------------------
To view the dashboard code, open the dashboard.ipynb file. By running all cells, the csv's are read. The dashboard is then saved as an html file in the last cell of code. All data of the explanatory variables (eerdere verdenking, geen inkomen and voortijdig schoolverlater), come from the Zicht op Wijken dashboard. The neighbourhood coordinates for Amsterdam come from maps.amsterdam.nl, this file (cleaned_wijken), was made ready-for-use before using it for the dashboard. Dataplatform.nl delivered the coordinate information for Utrecht and Den Haag. 

Required libraries:
numpy
pandas
geopandas
matplotlib
shapely

Enjoy using our dashboard!
---------------------------------------------------------------------------------------------